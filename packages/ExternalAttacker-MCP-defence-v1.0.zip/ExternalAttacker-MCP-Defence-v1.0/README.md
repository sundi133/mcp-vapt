# ExternalAttacker MCP Server

![ExternalAttacker-MCP](/images/ExternalAttacker-MCP-Banner.png)

## Model Context Protocol (MCP) Server for Security Assessment & Compliance

ExternalAttacker is a comprehensive security assessment platform that combines penetration testing, vulnerability scanning, and compliance validation with a natural language interface.

> 🔍 **Complete Security & Compliance Assessment with AI!**  
> Perform security assessments, compliance audits, and generate formal documentation using natural language.

## 🔍 What is ExternalAttacker?

ExternalAttacker combines the power of:

* **Automated Scanning**: Comprehensive toolset for external reconnaissance
* **Model Context Protocol (MCP)**: An open protocol for creating custom AI tools
* **Natural Language Processing**: Convert plain English queries into scanning commands

## 📱 Community

Join our Telegram channel for updates, tips, and discussion:
- **Telegram**: [https://t.me/root_sec](https://t.me/root_sec)

## ✨ Features

* **Natural Language Interface**: Run security assessments using plain English
* **🔍 Penetration Testing Tools**:
  * 🌐 Subdomain Discovery (subfinder)
  * 🔢 Port Scanning (naabu, nmap)
  * 🌍 HTTP Analysis (httpx)
  * 🛡️ CDN Detection (cdncheck)
  * 🔐 TLS Analysis (tlsx)
  * 📁 Directory Fuzzing (ffuf, gobuster)
  * 📝 DNS Enumeration (dnsx)
  * 🕸️ Web Crawling (katana)
  * 🛡️ Vulnerability Scanning (nuclei)
  * 💉 SQL Injection Testing (sqlmap)
  * ⚡ XSS Testing (dalfox)
  * 🔒 Password Cracking (hydra, john)

* **🏛️ Compliance & Governance** (NEW!):
  * 📋 NIST 800-53 Compliance Assessment
  * 🏢 FedRAMP Security Authorization
  * 🔒 SOC 2 & ISO 27001 Validation
  * 📄 OSCAL-Compliant Reporting
  * 📊 Security Control Gap Analysis
  * 📝 System Security Plan (SSP) Generation
  * 🔍 Automated Evidence Collection

* **⚡ Advanced Capabilities**:
  * 🥷 Stealth Scanning (cloud-optimized)
  * 🌊 Rate-Limited Reconnaissance
  * 🎯 Passive Intelligence Gathering
  * 📊 Integrated Compliance Reporting

## 📋 Prerequisites

* Python 3.8 or higher
* Go (for installing tools)
* MCP Client

## 🔧 Installation

1. Clone this repository:
    ```bash
    git clone https://github.com/mordavid/ExternalAttacker-MCP.git
    cd ExternalAttacker
    ```

2. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Install required Go tools:
   ```bash
   go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
   go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest
   go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest
   go install -v github.com/projectdiscovery/cdncheck/cmd/cdncheck@latest
   go install -v github.com/projectdiscovery/tlsx/cmd/tlsx@latest
   go install -v github.com/ffuf/ffuf@latest
   go install github.com/OJ/gobuster/v3@latest
   go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest
   ```

4. Run ExternalAttacker-App.py
    ```bash
    python ExternalAttacker-App.py
    # Access http://localhost:6991
    ```

5. Configure the MCP Server
    ```bash
    "mcpServers": {
        "ExternalAttacker-MCP": {
            "command": "python",
            "args": [
                "/Users/jyotirmoysundi/git/ExternalAttacker-MCP/ExternalAttacker-MCP.py"
            ]
        }
    }
    ```

## 🚀 Usage

### 🔍 Security Assessment Examples:
* "Scan example.com for subdomains using stealth techniques"
* "Check open ports on 192.168.1.1 with slow timing"
* "Analyze HTTP services and technologies on test.com"
* "Perform comprehensive vulnerability scan on target.com"
* "Test SQL injection vulnerabilities on login.example.com"

### 🏛️ Compliance Assessment Examples:
* "Run NIST 800-53 compliance scan on production.company.com"
* "Assess security controls for moderate baseline on our web app"
* "Generate System Security Plan for E-commerce Platform"
* "Perform compliance gap analysis against FedRAMP requirements"
* "Create OSCAL-compliant security documentation for audit"

### 📊 Combined Assessment Examples:
* "Perform complete security and compliance assessment on api.example.com"
* "Generate penetration test report with compliance mappings"
* "Scan infrastructure and validate NIST controls implementation"

## 📚 Documentation

* **[GovReady-Q Compliance Integration](GOVREADY_Q_INTEGRATION.md)** - Complete compliance platform guide
* **[Installation Guide](INSTALLATION.md)** - Comprehensive setup instructions
* **[Fly.io Deployment](FLY_DEPLOYMENT.md)** - Cloud deployment guide
* **[Red Team Examples](RED_TEAM_EXAMPLES.md)** - Advanced penetration testing workflows

## 📜 License

MIT License

## 🙏 Acknowledgments

* The ProjectDiscovery team for their excellent security tools
* The MCP community for advancing AI-powered tooling

---

_Note: This is a security tool. Please use responsibly and only on systems you have permission to test._